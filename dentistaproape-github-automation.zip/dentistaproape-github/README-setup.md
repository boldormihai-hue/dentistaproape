# Setup actualizare automata saptamanala

## Ce face acest sistem:
- In fiecare luni la 06:00 dimineata, GitHub ruleaza automat scriptul
- Scriptul cauta fiecare clinica pe Google Places API
- Actualizeaza: telefon, program, poze, rating, coordonate GPS, website
- Incarca automat fisierul actualizat pe Hostinger

---

## Pasi de configurare (o singura data)

### Pasul 1: Creeaza cont GitHub (gratuit)
- Mergi pe github.com si creeaza un cont daca nu ai
- Creeaza un repository nou: New → Repository name: `dentistaproape`
- Bifeaza "Public" (necesar pentru GitHub Actions gratuit)
- Apasa "Create repository"

### Pasul 2: Incarca fisierele pe GitHub
- Descarca GitHub Desktop de pe desktop.github.com (mai usor decat comenzi)
- Clone repository-ul nou creat
- Copiaza toate fisierele site-ului in folderul clonat
- Asigura-te ca structura e:
  ```
  dentistaproape/          ← folderul site-ului
    data/
      dentisti.json
    dentisti/
    index.html
    admin.html
  update_dentisti.py       ← scriptul Python
  .github/
    workflows/
      update-dentisti.yml  ← configurarea automata
  ```
- Commit & Push

### Pasul 3: Adauga secretele in GitHub
In repository-ul tau pe GitHub:
- Apasa **Settings** → **Secrets and variables** → **Actions**
- Apasa **New repository secret** si adauga:

**Secret 1:**
- Name: `GOOGLE_PLACES_API_KEY`  
- Value: `AIzaSyCmfEnfhid0k4Icgo8dNqIN145vKtpDKDg`

**Secret 2:**
- Name: `FTP_SERVER`
- Value: `gazduit pe Hostinger - vezi mai jos`

**Secret 3:**
- Name: `FTP_USERNAME`
- Value: `u724932456` (username-ul tau Hostinger din File Manager)

**Secret 4:**
- Name: `FTP_PASSWORD`
- Value: `parola contului Hostinger`

### Cum gasesti FTP Server pe Hostinger:
- Hostinger hPanel → Hosting → Manage → FTP Accounts
- Copiaza "FTP hostname" (ex: srv2063.hstgr.io sau similar)

### Pasul 4: Testeaza manual
In repository-ul tau pe GitHub:
- Apasa tab-ul **Actions**
- Click pe "Actualizare saptamanala dentisti"
- Apasa **Run workflow** → **Run workflow**
- Urmareste logurile - vei vedea cum se actualizeaza fiecare clinica

---

## Dupa setup
- Fiecare luni dimineata GitHub actualizeaza automat toate clinicile
- Primesti email daca ceva nu merge (GitHub notifica automat)
- Poti rula manual oricand din tab-ul Actions → Run workflow
