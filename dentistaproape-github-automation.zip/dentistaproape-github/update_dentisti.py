#!/usr/bin/env python3
"""
Script actualizare automata dentisti.json cu Google Places API
Ruleaza automat via GitHub Actions in fiecare luni dimineata
"""

import json
import time
import os
import re
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime

API_KEY = os.environ.get("GOOGLE_PLACES_API_KEY", "")
DATA_FILE = "dentistaproape/data/dentisti.json"
PHOTOS_DIR = "dentistaproape/data/photos"

def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")

def places_search(name, city):
    """Cauta clinica pe Google Places si returneaza place_id"""
    query = f"{name} {city} Romania stomatolog"
    params = urllib.parse.urlencode({
        "query": query,
        "key": API_KEY,
        "language": "ro",
        "region": "ro",
        "type": "dentist"
    })
    url = f"https://maps.googleapis.com/maps/api/place/textsearch/json?{params}"
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.loads(r.read())
        results = data.get("results", [])
        if results:
            return results[0]["place_id"]
        return None
    except Exception as e:
        log(f"  ⚠ Search error pentru {name}: {e}")
        return None

def places_details(place_id):
    """Extrage detalii complete pentru un place_id"""
    fields = ",".join([
        "name",
        "formatted_phone_number",
        "international_phone_number",
        "formatted_address",
        "opening_hours",
        "rating",
        "user_ratings_total",
        "photos",
        "website",
        "geometry",
        "url"
    ])
    params = urllib.parse.urlencode({
        "place_id": place_id,
        "fields": fields,
        "key": API_KEY,
        "language": "ro"
    })
    url = f"https://maps.googleapis.com/maps/api/place/details/json?{params}"
    try:
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.loads(r.read())
        return data.get("result", {})
    except Exception as e:
        log(f"  ⚠ Details error: {e}")
        return {}

def get_photo_url(photo_reference, max_width=800):
    """Construieste URL-ul pentru o poza Google Places"""
    params = urllib.parse.urlencode({
        "photoreference": photo_reference,
        "maxwidth": max_width,
        "key": API_KEY
    })
    return f"https://maps.googleapis.com/maps/api/place/photo?{params}"

def parse_opening_hours(details):
    """Converteste opening_hours Google la formatul nostru"""
    ZILE_MAP = {
        "Monday": "Luni",
        "Tuesday": "Marti",
        "Wednesday": "Miercuri",
        "Thursday": "Joi",
        "Friday": "Vineri",
        "Saturday": "Sambata",
        "Sunday": "Duminica"
    }
    # Cu diacritice corecte
    ZILE_RO = {
        "Luni": "Luni",
        "Marti": "Marți",
        "Miercuri": "Miercuri",
        "Joi": "Joi",
        "Vineri": "Vineri",
        "Sambata": "Sâmbătă",
        "Duminica": "Duminică"
    }
    
    opening = details.get("opening_hours", {})
    periods = opening.get("periods", [])
    weekday_text = opening.get("weekday_text", [])
    
    program = {
        "Luni": "Contactați clinica",
        "Marți": "Contactați clinica",
        "Miercuri": "Contactați clinica",
        "Joi": "Contactați clinica",
        "Vineri": "Contactați clinica",
        "Sâmbătă": "Contactați clinica",
        "Duminică": "Contactați clinica"
    }
    
    if periods:
        day_names = ["Duminica", "Luni", "Marti", "Miercuri", "Joi", "Vineri", "Sambata"]
        for period in periods:
            open_day = period.get("open", {})
            close_day = period.get("close", {})
            
            day_idx = open_day.get("day", 0)
            if 0 <= day_idx <= 6:
                day_key_raw = day_names[day_idx]
                day_key = ZILE_RO.get(day_key_raw, day_key_raw)
                
                open_time = open_day.get("time", "0000")
                close_time = close_day.get("time", "0000") if close_day else "0000"
                
                # Format HH:MM
                open_fmt = f"{open_time[:2]}:{open_time[2:]}"
                close_fmt = f"{close_time[:2]}:{close_time[2:]}"
                
                # 24h?
                if open_time == "0000" and close_time == "0000":
                    program[day_key] = "00:00–24:00"
                else:
                    program[day_key] = f"{open_fmt}–{close_fmt}"
    elif weekday_text:
        # Fallback: parse weekday_text
        for text in weekday_text:
            for en, ro in ZILE_MAP.items():
                if text.startswith(en):
                    zi_ro = ZILE_RO.get(ro, ro)
                    hours = text.split(": ", 1)[-1].strip()
                    if "Closed" in hours or "Închis" in hours:
                        program[zi_ro] = "Închis"
                    else:
                        # Converteste formatul Google (9:00 AM – 6:00 PM) la 24h
                        program[zi_ro] = convert_hours(hours)
    
    return program

def convert_hours(hours_str):
    """Converteste 9:00 AM - 6:00 PM la 09:00-18:00"""
    def to24(t):
        t = t.strip()
        if "AM" in t or "PM" in t:
            try:
                from datetime import datetime as dt
                for fmt in ["%I:%M %p", "%I %p"]:
                    try:
                        return dt.strptime(t, fmt).strftime("%H:%M")
                    except:
                        pass
        return t.replace(".", ":")
    
    # Replace various dash types
    hours_str = hours_str.replace("–", "-").replace("—", "-")
    if "-" in hours_str:
        parts = hours_str.split("-", 1)
        start = to24(parts[0].strip())
        end = to24(parts[1].strip())
        return f"{start}–{end}"
    return hours_str

def update_dentist(dentist, force=False):
    """Actualizeaza datele unui dentist din Google Places"""
    name = dentist["nume"]
    city = dentist["oras"]
    
    log(f"Procesez: {name} ({city})")
    
    # Cauta place_id
    place_id = places_search(name, city)
    if not place_id:
        log(f"  ✗ Nu a fost gasit pe Google Places")
        return dentist, False
    
    log(f"  ✓ Gasit: {place_id}")
    time.sleep(0.2)  # Rate limiting
    
    # Extrage detalii
    details = places_details(place_id)
    if not details:
        log(f"  ✗ Nu s-au putut extrage detaliile")
        return dentist, False
    
    changed = False
    
    # Telefon
    phone = details.get("international_phone_number") or details.get("formatted_phone_number", "")
    if phone and phone != dentist.get("telefon", ""):
        dentist["telefon"] = phone
        changed = True
        log(f"  📞 Tel: {phone}")
    
    # Website
    website = details.get("website", "")
    if website and not dentist.get("website"):
        dentist["website"] = website
        changed = True
        log(f"  🌐 Site: {website[:50]}")
    
    # Adresa
    address = details.get("formatted_address", "")
    if address and not dentist.get("adresa"):
        # Curata adresa (scoate Romania la final)
        address = re.sub(r',?\s*Romania\s*$', '', address, flags=re.IGNORECASE).strip()
        dentist["adresa"] = address
        changed = True
        log(f"  📍 Adresa: {address[:60]}")
    
    # Coordonate GPS
    geometry = details.get("geometry", {}).get("location", {})
    if geometry:
        dentist["lat"] = geometry.get("lat", 0)
        dentist["lng"] = geometry.get("lng", 0)
        changed = True
    
    # Google Maps URL
    maps_url = details.get("url", "")
    if maps_url and not dentist.get("google_maps_url"):
        dentist["google_maps_url"] = maps_url
        changed = True
    
    # Rating
    rating = details.get("rating", 0)
    reviews = details.get("user_ratings_total", 0)
    if rating:
        dentist["rating"] = round(rating, 1)
        dentist["nr_recenzii"] = reviews
        changed = True
        log(f"  ⭐ Rating: {rating} ({reviews} recenzii)")
    
    # Program
    if details.get("opening_hours"):
        program = parse_opening_hours(details)
        dentist["program"] = program
        changed = True
        log(f"  🕐 Program actualizat")
    
    # Poze
    photos = details.get("photos", [])
    if photos:
        # Prima poza = poza principala
        first_photo = photos[0].get("photo_reference", "")
        if first_photo:
            photo_url = get_photo_url(first_photo, 800)
            dentist["poza"] = photo_url
            changed = True
            log(f"  📸 {len(photos)} poze gasite")
        
        # Toate pozele
        dentist["poze_google"] = [
            get_photo_url(p.get("photo_reference", ""), 600)
            for p in photos[:5]
            if p.get("photo_reference")
        ]
    
    # Salveaza place_id pentru update-uri viitoare (mai rapid)
    dentist["google_place_id"] = place_id
    dentist["ultima_actualizare"] = datetime.now().strftime("%Y-%m-%d")
    
    if changed:
        log(f"  ✅ Actualizat cu succes!")
    else:
        log(f"  ℹ Nicio schimbare")
    
    return dentist, changed

def main():
    log("=" * 50)
    log("🦷 Actualizare dentisti.json cu Google Places API")
    log("=" * 50)
    
    if not API_KEY:
        log("❌ GOOGLE_PLACES_API_KEY nu e setat!")
        return
    
    # Citeste JSON
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    dentisti = data["dentisti"]
    log(f"📋 Total cabinete: {len(dentisti)}")
    log("")
    
    total_actualizati = 0
    
    for i, dentist in enumerate(dentisti):
        log(f"[{i+1}/{len(dentisti)}]")
        
        # Daca are deja place_id, mai rapid
        if dentist.get("google_place_id"):
            details = places_details(dentist["google_place_id"])
            if details:
                dentist, changed = update_dentist(dentist, force=True)
        else:
            dentist, changed = update_dentist(dentist)
        
        dentisti[i] = dentist
        if changed:
            total_actualizati += 1
        
        # Salveaza progresul dupa fiecare 10 dentisti (safety)
        if (i + 1) % 10 == 0:
            data["dentisti"] = dentisti
            with open(DATA_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            log(f"💾 Progress salvat ({i+1}/{len(dentisti)})")
        
        # Rate limiting: 0.5s intre requesturi
        time.sleep(0.5)
        log("")
    
    # Salveaza final
    data["dentisti"] = dentisti
    data["ultima_actualizare_globala"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    log("=" * 50)
    log(f"✅ Gata! {total_actualizati}/{len(dentisti)} cabinete actualizate")
    log(f"💾 Salvat in: {DATA_FILE}")
    log("=" * 50)

if __name__ == "__main__":
    main()
